import test from 'node:test'; import assert from 'node:assert/strict'; import fs from 'node:fs';
import {trips,travelers,filterTrips,baselineRank,validateRank} from '../traveler/core.js';
import { recommend } from '../traveler/recommend.js';

const expected = JSON.parse(fs.readFileSync(new URL('../data/Itera_PoC_Expected_Results.json', import.meta.url), 'utf8')).tests;

test('fixture integrity', () => { assert.equal(trips.length, 15); assert.equal(travelers.length, 10); });
for (const profile of travelers) {
    test('hard-filter matches answer key: ' + profile.id, () => {
        const answer = expected.find(x => x.traveler_id === profile.id); assert.ok(answer);
        const actual = filterTrips(profile).map(x => x.id).sort(); assert.deepEqual(actual, [...answer.eligible_trip_ids].sort());
        const ranked = baselineRank(profile, filterTrips(profile)); assert.ok(ranked.length <= 3);
        assert.ok(ranked.every(x => actual.includes(x.id)));
    });
}
test('reject unsafe LLM rank', () => { assert.throws(() => validateRank(['toubkal_hike'], filterTrips(travelers[0]))); });
test('reject missing accessibility data', () => { assert.deepEqual(filterTrips({ ...travelers[0], needs: { ...travelers[0].needs, wheelchair: null } }), []); });

test('reject invalid dates and nonpositive durations before ranking', () => {
    const p = travelers[0], t = filterTrips(p)[0];
    for (const patch of [{ duration_days: 0 }, { duration_days: -1 }, { price_mad: -1 }, { start_date: '2026-02-30' }, { start_date: '2026-12-1' }]) assert.deepEqual(filterTrips(p, [{ ...t, ...patch }]), []);
    for (const patch of [{ max_duration_days: 0 }, { budget_max_mad: -1 }, { available_from: '2026-02-30' }, { available_to: '2026-13-01' }]) assert.deepEqual(filterTrips({ ...p, ...patch }, [t]), []);
});
test('every required accessibility feature fails closed on unknown data', () => {
    const p = travelers[0], t = filterTrips(p)[0];
    for (const [need, field] of Object.entries({ wheelchair: 'wheelchair_access', accessible_bathroom: 'accessible_bathroom', step_free_transport: 'step_free_transport', needs_assistance: 'assistance_available' })) {
        for (const value of ['unknown', 'no', undefined]) assert.deepEqual(filterTrips({ ...p, needs: { ...p.needs, [need]: true } }, [{ ...t, accessibility: { ...t.accessibility, [field]: value } }]), []);
    }
});
test('rank validation rejects malformed, duplicate and excessive selections', () => {
    const allowed = filterTrips(travelers[0]), id = allowed[0].id;
    for (const ids of [null, {}, [1], [id, id], [id, id, id, id], ['invented']]) assert.throws(() => validateRank(ids, allowed));
    assert.deepEqual(validateRank([id], allowed), [allowed[0]]);
});

// Mocked traveler agent tests (moved from agent.test.js)
async function withModel(t, answer, run) {
    const llm = async () => ({ data: structuredClone(answer), usage: { input: 0, output: 0 }, provider: 'mock', model: 'mock', ms: 0 });
    await run(llm);
}
test('mocked traveler rejects ineligible or malformed model selections', async t => {
    for (const answer of [null, { ids: ['toubkal_hike'] }, { ids: ['invented'] }]) await withModel(t, answer, (llm) => assert.rejects(recommend(travelers[0], { llm }), /invalid or ineligible/));
});
test('mocked traveler returns only verified eligible listings', async t => {
    const allowed = filterTrips(travelers[0]);
    await withModel(t, { ids: [allowed[0].id] }, async (llm) => { const r = await recommend(travelers[0], { llm }); assert.equal(r.mode, 'ai_ranked'); assert.deepEqual(r.recommendations[0].trip, allowed[0]); assert.match(r.recommendations[0].explanation, /MAD/); });
});
test('baseline and no-match paths need no model', async () => {
    assert.equal((await recommend(travelers[0], { useAI: false })).mode, 'deterministic_baseline');
    assert.deepEqual(await recommend(travelers.find(p => p.id === 'nour')), { mode: 'no_matches', recommendations: [] });
});